MINT MONEY — AI FINANCIAL BUDGET ADVISOR

QUICK START
Double-click start.bat. The website opens locally. In the login form, paste a complete email address (for example, name@example.com), choose “Create an account”, and set a password of at least 8 characters. In demo mode, that account and budget are saved in this browser only. The password is hashed, but browser-only accounts are not suitable for sensitive or production use.

FEATURES
- Responsive home page, navigation, login, signup, and dashboard.
- Monthly income and seven spending categories with balance, savings-rate, and spending charts.
- Savings-goal monthly payment calculator.
- What-if savings preview.
- Download budget as CSV.
- AI budget coach with suggested questions.
- Transparent budget rules, privacy, fairness, and limitations.

REAL ONLINE ACCOUNTS (FOR HOSTING)
The page supports Supabase Auth for real email/password accounts, email confirmation, password reset, and cloud budgets. To activate it:
1. Create a Supabase project.
2. Run schema.sql in its SQL Editor (includes row-level security so users only access their own budget).
3. Add the project's URL and publishable key to config.js. Do not use a service-role secret key in the browser.
4. Add the final Netlify URL to Supabase Auth's Site URL and Redirect URLs.
5. Upload this folder to Netlify. Netlify requires a connected account to keep a permanent site; its default URL ends in .netlify.app. A custom .in domain must be owned and connected separately.

AI COACH
Qwen2.5 0.5B Instruct runs in the browser through WebLLM and WebGPU. No AI API key is needed. First use downloads model files (roughly 500 MB) and requires internet; later visits can use the browser cache. Use recent Chrome or Edge. The AI may make mistakes and provides educational guidance only.

LOCAL SERVER
start.bat uses Python's launcher to serve the site at localhost. Keep its window open while using the app.
