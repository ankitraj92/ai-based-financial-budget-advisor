// Add your Supabase project values here before deployment.
// Use the project's URL and publishable (anon) key only. Never put a service-role key here.
window.MINT_CONFIG = {
  supabaseUrl: "",
  supabaseAnonKey: ""
};
